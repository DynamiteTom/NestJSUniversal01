export const ROUTES = [
  '/',
  '/speakers'
];
